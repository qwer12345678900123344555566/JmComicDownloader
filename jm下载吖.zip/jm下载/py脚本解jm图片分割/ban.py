import hashlib

def get_num(e: str, t: str) -> int:
    print(f"\n>>> 开始计算: e={e}, t={t}")

    # 拼接字符串
    concat = e + t
    print(f"[1] 拼接字符串: {concat}")

    # 计算 md5
    md5_val = hashlib.md5(concat.encode("utf-8")).hexdigest()
    print(f"[2] MD5: {md5_val}")

    # 取最后一位
    last_char = md5_val[-1]
    print(f"[3] MD5 最后一位: {last_char}")

    # 转成 charCode
    n = ord(last_char)
    print(f"[4] charCode: {n}")

    # 范围判断
    e_int = int(e)
    if 268850 <= e_int <= 421925:
        n = n % 10
        print(f"[5] e 在 268850~421925 范围内 → n % 10 = {n}")
    elif e_int >= 421926:
        n = n % 8
        print(f"[5] e ≥ 421926 → n % 8 = {n}")
    else:
        print(f"[5] e < 268850 → 不取余，n={n}")

    # 映射
    mapping = {
        0: 2, 1: 4, 2: 6, 3: 8, 4: 10,
        5: 12, 6: 14, 7: 16, 8: 18, 9: 20
    }
    a = mapping.get(n, 10)
    print(f"[6] 映射结果: {a}\n")

    return a


if __name__ == "__main__":
    print("输入 e 和 t 进行计算（输入 '退出' 可结束）")
    while True:
        e = input("请输入 e (aid): ").strip()
        if e.lower() == "退出":
            print("程序已退出。")
            break

        t = input("请输入 t (filename): ").strip()
        if t.lower() == "退出":
            print("程序已退出。")
            break

        try:
            result = get_num(e, t)
            print(f"最终结果: {result}\n")
        except Exception as ex:
            print(f"出错: {ex}\n")