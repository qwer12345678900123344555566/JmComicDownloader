import os
import requests
from PIL import Image
from io import BytesIO
import concurrent.futures
import re
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import hashlib
from typing import Union

# 配置
IMAGE_LINKS_FILE = "/storage/emulated/0/Download/Python/测试/图片链接.txt"
OUTPUT_FOLDER = "/storage/emulated/0/Download/Python/测试/禁漫图片/"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

class JmImageTool:
    
    @classmethod
    def get_num(cls, e: str, t: str) -> int:
        """计算分割数（保持原有逻辑）"""
        concat = e + t
        md5_val = hashlib.md5(concat.encode("utf-8")).hexdigest()
        last_char = md5_val[-1]
        n = ord(last_char)
        
        e_int = int(e)
        if 268850 <= e_int <= 421925:
            n = n % 10
        elif e_int >= 421926:
            n = n % 8
        
        mapping = {
            0: 2, 1: 4, 2: 6, 3: 8, 4: 10,
            5: 12, 6: 14, 7: 16, 8: 18, 9: 20
        }
        return mapping.get(n, 10)

    @classmethod
    def decode_and_save(cls, num: int, img_src: Image.Image, decoded_save_path: str) -> None:
        """图片重组（保持原有逻辑）"""
        if num == 0:
            img_src.save(decoded_save_path)
            return

        w, h = img_src.size
        img_decode = Image.new("RGB", (w, h))
        over = h % num
        
        for i in range(num):
            move = h // num
            y_src = h - (move * (i + 1)) - over
            y_dst = move * i

            if i == 0:
                move += over
            else:
                y_dst += over

            img_decode.paste(
                img_src.crop((0, y_src, w, y_src + move)),
                (0, y_dst, w, y_dst + move)
            )

        img_decode.save(decoded_save_path)

    @classmethod
    def open_image(cls, fp: Union[str, bytes]):
        """打开图片"""
        fp = fp if isinstance(fp, str) else BytesIO(fp)
        return Image.open(fp)

def create_pdf(chapter_dir, delete_images=True):
    """生成PDF（修复缝隙问题）"""
    pdf_path = f"{chapter_dir}.pdf"
    image_files = sorted(
        [f for f in os.listdir(chapter_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))],
        key=lambda x: int(x.split('.')[0])
     )    
    if not image_files:
        print(f"没有图片文件: {chapter_dir}")
        return False

    # 获取第一张图片的尺寸（所有图片尺寸应相同）
    first_img_path = os.path.join(chapter_dir, image_files[0])
    with Image.open(first_img_path) as img:
        pdf_width, pdf_height = img.size

    # 创建PDF（使用图片实际尺寸）
    c = canvas.Canvas(pdf_path, pagesize=(pdf_width, pdf_height))
    
    for img_file in image_files:
        img_path = os.path.join(chapter_dir, img_file)
        try:
            with Image.open(img_path) as img:
                # 直接绘制图片，不缩放、不偏移
                c.drawImage(img_path, 0, 0, width=pdf_width, height=pdf_height, preserveAspectRatio=True)
                c.showPage()
            
            if delete_images:
                os.remove(img_path)
        except Exception as e:
            print(f"处理图片失败 {img_file}: {str(e)}")
    
    c.save()
    
    if delete_images:
        try:
            os.rmdir(chapter_dir)
        except OSError:
            pass
    
    print(f"PDF生成成功: {pdf_path}")
    return True

# ------------------- 以下代码保持不变 -------------------
def extract_chapter_number(title):
    """从标题提取话数用于排序"""
    match = re.search(r'第(\d+)话', title)
    return int(match.group(1)) if match else 99999

def download_image(url, save_path):
    """下载并处理单张图片"""
    try:
        parts = url.split('/')
        aid = parts[-2]
        filename = parts[-1].split('.')[0]
        
        headers = {'Referer': 'https://18comic.vip/', 'User-Agent': 'Mozilla/5.0'}
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        
        img = JmImageTool.open_image(resp.content)
        num = JmImageTool.get_num(aid, filename)
        JmImageTool.decode_and_save(num, img, save_path)
        return True
    except Exception as e:
        print(f"下载失败 {url}: {str(e)}")
        return False

def process_chapter(chapter_title, image_urls, thread_count=4):
    """处理单话漫画"""
    print(f"\n开始下载: {chapter_title}")
    chapter_dir = os.path.join(OUTPUT_FOLDER, chapter_title)
    os.makedirs(chapter_dir, exist_ok=True)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=thread_count) as executor:
        futures = [executor.submit(download_image, url, os.path.join(chapter_dir, f"{i:03d}.jpg")) 
                  for i, url in enumerate(image_urls, 1)]
        success = sum(f.result() for f in concurrent.futures.as_completed(futures))
    
    print(f"下载完成: {success}/{len(image_urls)} 成功 | 章节: {chapter_title}")
    if success > 0:
        create_pdf(chapter_dir)
    return success == len(image_urls)

def parse_chapters():
    """解析章节信息并按话数排序"""
    with open(IMAGE_LINKS_FILE, 'r', encoding='utf-8') as f:
        content = f.read()
    
    chapters = []
    for match in re.finditer(r'### (.*?)\n((?:http[^\n]*\n)+)', content):
        title = match.group(1).strip()
        urls = [url.strip() for url in match.group(2).split('\n') if url.strip()]
        chapters.append((title, urls))
    
    chapters.sort(key=lambda x: extract_chapter_number(x[0]))
    return chapters

def main():
    chapters = parse_chapters()
    if not chapters:
        print("未找到有效章节！请检查链接文件")
        return
    
    while True:
        print("\n===== 章节列表 =====")
        for i, (title, urls) in enumerate(chapters, 1):
            print(f"{i}. {title} ({len(urls)}页)")
        
        choice = input("\n输入章节号 (如 1 或 1,3 或 1-3)，或输入 0 退出: ").strip()
        if choice == "0":
            break
        
        try:
            selected = []
            for part in choice.replace('，', ',').split(','):
                if '-' in part:
                    start, end = map(int, part.split('-'))
                    selected.extend(range(start-1, end))
                else:
                    selected.append(int(part)-1)
            
            thread_count = min(8, max(1, int(input("线程数 (1-8): ") or 4)))
            for idx in selected:
                if 0 <= idx < len(chapters):
                    process_chapter(chapters[idx][0], chapters[idx][1], thread_count)
        except ValueError:
            print("输入无效！")

if __name__ == '__main__':
    main()