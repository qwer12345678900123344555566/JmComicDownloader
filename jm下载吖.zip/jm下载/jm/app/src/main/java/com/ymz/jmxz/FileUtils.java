package com.ymz.jmxz;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.net.Uri;

import java.io.*;
import java.util.ArrayList;

public class FileUtils {

    public static String readTextFromUri(Context ctx, Uri uri) throws Exception {
        InputStream is = ctx.getContentResolver().openInputStream(uri);
        if (is == null) throw new Exception("cannot open input stream");
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append("\n");
        br.close();
        is.close();
        return sb.toString();
    }

    public static boolean deleteRecursively(File f) {
        if (f == null || !f.exists()) return true;
        if (f.isDirectory()) {
            File[] ch = f.listFiles();
            if (ch != null) {
                for (File c : ch) deleteRecursively(c);
            }
        }
        return f.delete();
    }

    public static void copyToClipboard(Context ctx, String text) {
        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("path", text));
    }

    /** 列出目录直系子目录 */
    public static ArrayList<File> listChildDirs(File root) {
        ArrayList<File> res = new ArrayList<File>();
        if (root != null && root.exists()) {
            File[] files = root.listFiles();
            if (files != null) {
                for (File f : files) if (f.isDirectory()) res.add(f);
            }
        }
        return res;
    }
}