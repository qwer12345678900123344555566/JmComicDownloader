package com.ymz.jmxz;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.*;

public class Downloader {

    public interface Listener {
        void onLog(String msg);
        void onProgress(String chapter, int done, int total);
        void onAllDone(File targetDir, File pdfFile);
        void onError(String message);
    }

    private final Listener listener;
    private final String txtContent;
    private final File targetDir;
    private final int chapterThreadCount; // 章节线程数
    private final int imageThreadCount; // 图片线程数
    private final int[] selectedIndices; // 0-based

    public Downloader(Listener l, String txt, File dir, int chapterThreads, int imageThreads, int[] selected) {
        this.listener = l;
        this.txtContent = txt;
        this.targetDir = dir;
        this.chapterThreadCount = chapterThreads;
        this.imageThreadCount = imageThreads;
        this.selectedIndices = selected;
    }


    public void start() {
    new Thread(new Runnable() {
        @Override public void run() {
            try {
                Map<String, ArrayList<String>> chapters = parseChapters(txtContent);
                ArrayList<String> titles = new ArrayList<String>(chapters.keySet());
                Collections.sort(titles, new Comparator<String>() {
                    public int compare(String a, String b) {
                        return extractChapterNumber(a) - extractChapterNumber(b);
                    }
                });

                ArrayList<Integer> indices = new ArrayList<Integer>();
                if (selectedIndices != null && selectedIndices.length > 0) {
                    for (int i = 0; i < selectedIndices.length; i++) indices.add(selectedIndices[i]);
                } else {
                    for (int i = 0; i < titles.size(); i++) indices.add(i);
                }

                // 使用 chapterThreadCount 作为章节下载的线程池大小
                ExecutorService chapterPool = Executors.newFixedThreadPool(chapterThreadCount);
                ArrayList<Future<?>> chapterFutures = new ArrayList<Future<?>>();

                for (int idx : indices) {
                    if (idx < 0 || idx >= titles.size()) continue;
                final   String title = titles.get(idx);
final ArrayList<String> urls = chapters.get(title);
                  final  File chapDir = new File(targetDir, title);
                    chapDir.mkdirs();

                    // 提交每个章节的下载任务到章节线程池
                    chapterFutures.add(chapterPool.submit(new Callable<Void>() {
                        public Void call() throws Exception {
                            downloadChapter(title, urls, chapDir);
                            // 生成单页PDF
                            File pdfFile = new File(chapDir.getAbsolutePath() + ".pdf");
                            ArrayList<File> imgFiles = enumImages(chapDir);
                            PdfUtils.imagesToSinglePagePdf(imgFiles, pdfFile);
                            // 清理图片
                            for (File f : imgFiles) f.delete();
                            // 删除空文件夹
                            chapDir.delete();
                            listener.onLog("PDF生成成功: " + pdfFile.getAbsolutePath());
                            return null;
                        }
                    }));
                }

                // 等待所有章节下载完成
                for (Future<?> f : chapterFutures) f.get();

                chapterPool.shutdown();
                // 若只有一个章节，也把其 PDF 路径回调；多章节回调最后一个
                ArrayList<File> allPdfs = listPdfs(targetDir);
                File lastPdf = allPdfs.size() > 0 ? allPdfs.get(allPdfs.size()-1) : null;
                listener.onAllDone(targetDir, lastPdf);
            } catch (Exception e) {
                listener.onError("任务失败: " + e.getMessage());
            }
        }
    }).start();
}


    private static Map<String, ArrayList<String>> parseChapters(String content) {
        // 解析形如： ### 标题 \n url...\n
        LinkedHashMap<String, ArrayList<String>> map = new LinkedHashMap<String, ArrayList<String>>();
        String[] lines = content.split("\n");
        String currentTitle = null;
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.startsWith("### ")) {
                currentTitle = line.substring(4).trim();
                if (!map.containsKey(currentTitle)) map.put(currentTitle, new ArrayList<String>());
            } else if (line.startsWith("http")) {
                if (currentTitle != null) map.get(currentTitle).add(line);
            }
        }
        return map;
    }

    private static int extractChapterNumber(String title) {
        // “第(\d+)话”
        try {
            int s = title.indexOf("第");
            int e = title.indexOf("话");
            if (s >= 0 && e > s) {
                String num = title.substring(s+1, e);
                return Integer.parseInt(num);
            }
        } catch (Exception ignored) {}
        return 99999;
    }

    private void downloadChapter(final String title, final ArrayList<String> urls, final File chapDir) throws Exception {
    listener.onLog("\n开始下载: " + title);
    final int total = urls.size();
    final int[] done = new int[]{0};

    // 使用 imageThreadCount 作为图片下载的线程池大小
    ExecutorService pool = Executors.newFixedThreadPool(imageThreadCount);
    ArrayList<Future<Boolean>> futures = new ArrayList<Future<Boolean>>();

    for (int i = 0; i < urls.size(); i++) {
        final int index = i;
        final String url = urls.get(i);
        final File outFile = new File(chapDir, String.format("%03d.jpg", index+1));

        futures.add(pool.submit(new Callable<Boolean>() {
            public Boolean call() throws Exception {
                boolean ok = downloadOne(url, outFile);
                synchronized (done) {
                    done[0]++;
                    listener.onProgress(title, done[0], total);
                }
                return Boolean.valueOf(ok);
            }
        }));
    }

    for (Future<Boolean> f : futures) f.get();
    pool.shutdown();
    listener.onLog("下载完成: " + done[0] + "/" + total + " | 章节: " + title);
}


    private boolean downloadOne(String urlStr, File outFile) {
        int attempt = 0;
        while (attempt < 9999) {
            attempt++;
            HttpURLConnection conn = null;
            InputStream is = null;
            FileOutputStream fos = null;
            try {
                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("Referer", "https://18comic.vip/");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                conn.connect();
                int code = conn.getResponseCode();
                if (code != 200) throw new Exception("HTTP " + code);
                is = conn.getInputStream();
                // 读为 Bitmap
                Bitmap raw = BitmapFactory.decodeStream(is);
                if (raw == null) throw new Exception("decode bitmap null");

                // aid / filename 用于切片数
                String[] parts = urlStr.split("/");
                String aid = parts[parts.length - 2];
                String filename = parts[parts.length - 1];
                int dot = filename.indexOf(".");
                if (dot > 0) filename = filename.substring(0, dot);
                int num = JmImageTool.getNum(aid, filename);

                Bitmap decoded = JmImageTool.decodeToBitmap(num, raw);
                raw.recycle();

                fos = new FileOutputStream(outFile);
                decoded.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                decoded.recycle();
                return true;
            } catch (Exception e) {
                try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
            } finally {
                try { if (is != null) is.close(); } catch (Exception ignored) {}
                if (conn != null) conn.disconnect();
                try { if (fos != null) fos.close(); } catch (Exception ignored) {}
            }
        }
        return false;
    }

    private static ArrayList<File> enumImages(File dir) {
        ArrayList<File> list = new ArrayList<File>();
        File[] fs = dir.listFiles();
        if (fs != null) {
            Arrays.sort(fs, new Comparator<File>() {
                public int compare(File a, File b) {
                    return a.getName().compareTo(b.getName());
                }
            });
            for (File f : fs) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp")) {
                    list.add(f);
                }
            }
        }
        return list;
    }

    private static ArrayList<File> listPdfs(File dir) {
        ArrayList<File> res = new ArrayList<File>();
        File[] fs = dir.listFiles();
        if (fs != null) {
            Arrays.sort(fs, new Comparator<File>() {
                public int compare(File a, File b) { return a.getName().compareTo(b.getName()); }
            });
            for (File f : fs) {
                if (f.isFile() && f.getName().toLowerCase().endsWith(".pdf")) res.add(f);
            }
        }
        return res;
    }
}