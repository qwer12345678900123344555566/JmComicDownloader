package com.ymz.jmxz;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class PdfUtils {

    /**
     * 将多张图片垂直拼接到一页 PDF 中（无缩放、无缝）
     * 优化：避免重复解码，提升速度；每张图片水平居中于页面宽度
     */
    public static File imagesToSinglePagePdf(ArrayList<File> imageFiles, File outPdf) throws Exception {
        if (imageFiles == null || imageFiles.size() == 0) {
            throw new Exception("no images");
        }

        // 1. 先解码所有图片，获取尺寸并缓存 Bitmap（避免重复 decode）
        ArrayList<Bitmap> bitmaps = new ArrayList<>();
        int maxW = 0;
        int totalH = 0;

        for (File f : imageFiles) {
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
            // 只获取尺寸的话可以用 inJustDecodeBounds，但我们要绘制原图，所以直接解码
            Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath(), opt);
            if (bm == null) {
                throw new Exception("decode fail: " + f.getName());
            }
            bitmaps.add(bm);

            int w = bm.getWidth();
            int h = bm.getHeight();
            if (w > maxW) {
                maxW = w;
            }
            totalH += h;
        }

        // 2. 创建 PDF 文档，页面尺寸为：最大宽度 + 总高度
        PdfDocument doc = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(maxW, totalH, 1).create();
        PdfDocument.Page page = doc.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        // 3. 依次绘制每张图片，水平居中（垂直方向紧贴）
        int y = 0;
        for (Bitmap bm : bitmaps) {
            int imgW = bm.getWidth();
            int imgH = bm.getHeight();

            // 水平居中：页面宽度是 maxW，图片宽度可能更小，计算左右留空，让图片居中
            int x = (maxW - imgW) / 2;  // 水平偏移，让图片在 maxW 宽度内居中

            canvas.drawBitmap(bm, x, y, null);
            y += imgH;
        }

      // 4. 结束页面并写入文件
doc.finishPage(page);

FileOutputStream fos = null;
try {
    fos = new FileOutputStream(outPdf);
    doc.writeTo(fos);
} catch (Exception e) {
    throw new Exception("Failed to write PDF: " + e.getMessage(), e);
} finally {
    if (fos != null) {
        try {
            fos.close();
        } catch (Exception e) {
            // 可以记录日志，但不需要抛出异常
            e.printStackTrace();
        }
    }
    doc.close();
}

// 5. 释放 Bitmap 内存（建议调用方在使用完后手动回收，或者在此处循环回收）
for (Bitmap bm : bitmaps) {
    bm.recycle();
}

return outPdf;

    }
}
