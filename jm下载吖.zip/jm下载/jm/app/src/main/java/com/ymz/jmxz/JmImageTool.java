package com.ymz.jmxz;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;

import java.security.MessageDigest;

public class JmImageTool {

    public static int getNum(String e, String t) {
        try {
            String concat = e + t;
            String md5 = md5Hex(concat);
            char last = md5.charAt(md5.length() - 1);
            int n = (int) last;
            int eInt = Integer.parseInt(e);
            if (268850 <= eInt && eInt <= 421925) n = n % 10;
            else if (eInt >= 421926) n = n % 8;

            int[] map = new int[]{2,4,6,8,10,12,14,16,18,20};
            int idx = n % 10;
            return map[idx];
        } catch (Exception ex) {
            return 10;
        }
    }

    private static String md5Hex(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] b = md.digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte value : b) {
            String x = Integer.toHexString((value & 0xFF) | 0x100).substring(1,3);
            sb.append(x);
        }
        return sb.toString();
    }

    /** 无缩放重组，返回新 Bitmap（无缝） */
    public static Bitmap decodeToBitmap(int num, Bitmap src) {
        if (num == 0) return src.copy(Bitmap.Config.ARGB_8888, false);

        int w = src.getWidth();
        int h = src.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);

        int over = h % num;
        for (int i = 0; i < num; i++) {
            int move = h / num;
            int ySrc = h - (move * (i + 1)) - over;
            int yDst = move * i;
            if (i == 0) move += over;
            else yDst += over;

            Rect srcRect = new Rect(0, ySrc, w, ySrc + move);
            Rect dstRect = new Rect(0, yDst, w, yDst + move);
            cv.drawBitmap(src, srcRect, dstRect, null);
        }
        return out;
    }
}