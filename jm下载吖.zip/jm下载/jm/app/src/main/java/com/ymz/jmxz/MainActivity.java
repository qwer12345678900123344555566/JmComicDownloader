package com.ymz.jmxz;

import android.Manifest;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements Downloader.Listener {

    private static final int REQ_FILE = 1;
    private static final int REQ_PERMS = 2;

    private Uri fileUri = null;
    private String txtContent = null;

    private File baseDir;

    private TextView tvSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvSelected = (TextView) findViewById(R.id.tv_selected_file);

        ensureStorage();

        findViewById(R.id.btn_upload).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickTxt(); }
        });

        findViewById(R.id.btn_start).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askInputsAndStart(); }
        });

        findViewById(R.id.btn_view).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showProcessedFilesDialog(); }
        });

        findViewById(R.id.btn_tutorial).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTutorialDialog(); }
        });

        findViewById(R.id.tv_group).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openQQGroup(); }
        });
    }

    private void ensureStorage() {
        baseDir = new File(Environment.getExternalStorageDirectory(), "禁漫下载器");
        if (!baseDir.exists()) baseDir.mkdirs();

        ArrayList<String> need = new ArrayList<String>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[need.size()]), REQ_PERMS);
        }
    }

    private void pickTxt() {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("text/plain");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(it, "选择TXT链接文件"), REQ_FILE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && res == RESULT_OK && data != null) {
            fileUri = data.getData();
            try {
                txtContent = FileUtils.readTextFromUri(this, fileUri);
                tvSelected.setText("已选择文件：" + fileUri.toString());
                Toast.makeText(this, "文件读取成功", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "读取失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void askInputsAndStart() {
    if (txtContent == null || txtContent.trim().length() == 0) {
        Toast.makeText(this, "请先上传链接文件", Toast.LENGTH_SHORT).show();
        return;
    }
    View view = LayoutInflater.from(this).inflate(R.layout.dialog_inputs, null);
    final EditText etName = (EditText) view.findViewById(R.id.et_name);
    final EditText etThreads = (EditText) view.findViewById(R.id.et_threads); // 章节线程数
    final EditText etImageThreads = (EditText) view.findViewById(R.id.et_imageThreads); // 图片线程数
    final EditText etChapters = (EditText) view.findViewById(R.id.et_chapters);

    new AlertDialog.Builder(this)
            .setTitle("下载设置")
            .setView(view)
            .setPositiveButton("开始", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    String name = etName.getText().toString().trim();
                    if (name.length() == 0) name = "未命名漫画";
                    
                    // 解析章节线程数，不限制范围
                    int chapterThreads = 4; // 默认章节线程数
                    try {
                        String t = etThreads.getText().toString().trim();
                        if (t.length() > 0) {
                            chapterThreads = Integer.parseInt(t);
                            if (chapterThreads < 1) chapterThreads = 1; // 最小值为1
                        }
                    } catch (Exception ignored) {
                        // 保持默认值
                    }

                    // 解析图片线程数，不限制范围
                    int imageThreads = 4; // 默认图片线程数
                    try {
                        String t = etImageThreads.getText().toString().trim();
                        if (t.length() > 0) {
                            imageThreads = Integer.parseInt(t);
                            if (imageThreads < 1) imageThreads = 1; // 最小值为1
                        }
                    } catch (Exception ignored) {
                        // 保持默认值
                    }

                    int[] indices = parseSelection(etChapters.getText().toString().trim());

                    String ts = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                    File target = new File(baseDir, name + "_" + ts);
                    if (!target.exists()) target.mkdirs();

                    Toast.makeText(MainActivity.this, "开始下载到: " + target.getAbsolutePath(), Toast.LENGTH_LONG).show();

                    // 修改 Downloader 构造函数以接收 chapterThreads 和 imageThreads
                    Downloader dl = new Downloader(MainActivity.this, txtContent, target, chapterThreads, imageThreads, indices);
                    dl.start();
                }
            })
            .setNegativeButton("取消", null)
            .show();
}



/** 解析字符串为 0-based 索引数组，支持大数、负数自动转正、去重 */
private int[] parseSelection(String s) {
    if (s == null || s.trim().isEmpty()) {
        return new int[0];
    }

    // 统一替换中文逗号和空格
    s = s.replace("，", ",").replaceAll("\\s+", "");
    
    Set<Integer> indexSet = new LinkedHashSet<>(); // 自动去重且保持顺序
    String[] parts = s.split(",");

    for (String part : parts) {
        if (part.isEmpty()) {
            continue;
        }

        // 处理负数：全部转正
        part = part.replace("-", ",-").replaceAll("^,", ""); // 分离连字符和负号
        String[] subParts = part.split(",");

        try {
            if (subParts.length == 1) { // 单个数字，如 "5" 或 "-3"
                int num = Math.abs(Integer.parseInt(subParts[0]));
                if (num > 0) { // 忽略 0，因为输出是 0-based
                    indexSet.add(num - 1);
                }
            } else if (subParts.length == 2) { // 范围，如 "5-8" 或 "-3--1"
                int start = Math.abs(Integer.parseInt(subParts[0]));
                int end = Math.abs(Integer.parseInt(subParts[1]));
                
                if (start > end) { // 自动交换，确保 start <= end
                    int temp = start;
                    start = end;
                    end = temp;
                }
                
                // 避免超大范围导致内存问题（限制最大范围 100000）
                if (end - start > 100_000) {
                    end = start + 100_000;
                }
                
                // 添加范围内的所有数字（0-based）
                for (int i = start; i <= end; i++) {
                    if (i > 0) { // 忽略 0
                        indexSet.add(i - 1);
                    }
                }
            }
        } catch (NumberFormatException e) {
            // 忽略无效部分，如 "abc" 或 "1-2-3"
        }
    }

    // 转换为数组
    int[] result = new int[indexSet.size()];
    int i = 0;
    for (int num : indexSet) {
        result[i++] = num;
    }
    return result;
}

    private void showTutorialDialog() {
        new AlertDialog.Builder(this)
            .setTitle("使用教程")
            .setMessage("1）点击下方“🌈加入交流群”，获取相关油猴脚本\n"
                       +"2）在 JM 官网使用脚本下载想要的漫画图片链接（TXT）\n"
                       +"3）回到本软件：上传TXT → 设置线程/章节/名称 → 开始下载\n"
                       +"4）下载完成可选择是否压缩为ZIP\n【压缩过程因为没有进度条显示，过大文件会导致卡住的假像，其实是正在压缩，可以选择到mt管理器手动压缩(https://mt2.cn/)】\n"
                       +"5）在“查看已下载”中管理、分享或删除")
            .setPositiveButton("我知道了", null)
            .show();
    }

    private void openQQGroup() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://qun.qq.com/universal-share/share?ac=1&authKey=LhCE9iRduLjygt4%2FeNn1VFOOUDCxFkXav2ja%2FzFtJ8WLMOUHpPStreHqQKRH9S83&busi_data=eyJncm91cENvZGUiOiIxMDQ2NzU1NjgxIiwidG9rZW4iOiJDbjA3NFVPSm0wSUp0cWpoWkZBTzh1NGVMVDRBYXduODBFN3FlVG1LUlZPWkJsZlNpZjFvM1A2KzgwY2VQWGVvIiwidWluIjoiMjkwMTI1NjQzNSJ9&data=KtHaRQiNH8BmFdwgWNzt1Ix_69v_64y3BdDJbs44XSyg-9ZaGP8ENakQN7UV1v4MtZS_ighoPxGU465_qWjxHQ&svctype=4&tempid=h5_group_info"));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "无法打开QQ群链接\n请直接QQ内搜索群号：\n 1046755681", Toast.LENGTH_SHORT).show();
        }
    }

    /** —— Downloader.Listener 回调 —— */
    @Override public void onLog(final String msg) {
        runOnUiThread(new Runnable() { @Override public void run() {
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
        }});
    }

    @Override public void onProgress(final String chapter, final int done, final int total) {
        // 若需要可加进度条，这里先 Toast 简化
    }

    @Override public void onAllDone(final File targetDir, final File pdfFile) {
        runOnUiThread(new Runnable() { @Override public void run() {
            // 询问是否压缩
            new AlertDialog.Builder(MainActivity.this)
                .setTitle("下载完成")
                .setMessage("是否将目录下PDF打包为压缩包？\n" + targetDir.getAbsolutePath())
                .setPositiveButton("压缩", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        try {
                            String zipPath = targetDir.getAbsolutePath() + ".zip";
                            ZipUtils.zip(targetDir.getAbsolutePath(), zipPath);
                            Toast.makeText(MainActivity.this, "压缩完成: " + zipPath, Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "压缩失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("暂不", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        FileUtils.copyToClipboard(MainActivity.this, targetDir.getAbsolutePath());
                        Toast.makeText(MainActivity.this, "已复制目录路径，可自行压缩", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
        }});
    }

    @Override public void onError(final String message) {
        runOnUiThread(new Runnable() { @Override public void run() {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        }});
    }

    /** —— 查看已下载 —— */
    private void showProcessedFilesDialog() {
        final ArrayList<File> comics = FileUtils.listChildDirs(baseDir);
        if (comics.size() == 0) {
            Toast.makeText(this, "暂无已下载漫画", Toast.LENGTH_SHORT).show();
            return;
        }
        View v = getLayoutInflater().inflate(R.layout.dialog_downloads, null);
        ListView lv = (ListView) v.findViewById(R.id.lv_downloads);
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("已下载漫画")
                .setView(v)
                .setNegativeButton("关闭", null)
                .create();

        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return comics.size(); }
            @Override public Object getItem(int position) { return comics.get(position); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(final int position, View convertView, android.view.ViewGroup parent) {
                View row = convertView;
                if (row == null) row = getLayoutInflater().inflate(R.layout.item_download_row, parent, false);
                final File dir = comics.get(position);
                TextView tv = (TextView) row.findViewById(R.id.tv_name);
                tv.setText(dir.getName());
                Button btnShare = (Button) row.findViewById(R.id.btn_share);
                Button btnDel = (Button) row.findViewById(R.id.btn_delete);

                btnShare.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        // 规则：优先分享 zip；若无 zip，先询问是否压缩；压完再分享
                        final File zip = new File(dir.getAbsolutePath() + ".zip");
                        if (!zip.exists()) {
                            new AlertDialog.Builder(MainActivity.this)
                                .setTitle("未发现压缩包")
                                .setMessage("是否先压缩该漫画？\n" + dir.getAbsolutePath())
                                .setPositiveButton("压缩后分享", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            ZipUtils.zip(dir.getAbsolutePath(), zip.getAbsolutePath());
                                            Toast.makeText(MainActivity.this, "压缩完成", Toast.LENGTH_SHORT).show();
                                            shareFile(zip);
                                        } catch (Exception e) {
                                            Toast.makeText(MainActivity.this, "压缩失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                })
                                .setNegativeButton("取消", null)
                                .show();
                        } else {
                            shareFile(zip);
                        }
                    }
                });

                btnDel.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        confirmDelete(dir, new Runnable() {
                            @Override public void run() {
                                dlg.dismiss();
                                showProcessedFilesDialog();
                            }
                        });
                    }
                });

                return row;
            }
        });

        dlg.show();
    }

    /** —— 你的分享逻辑（原封不动 + FileProvider） —— */
    private void shareFile(File file) {
        if (!file.exists()) {
            Toast.makeText(this, "文件不存在", Toast.LENGTH_SHORT).show();
            return;
        }
        // Android 6.0 动态权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                return;
            }
        }
        // Android 11+ 特殊处理入口
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                    Toast.makeText(this, "请授予「所有文件访问权限」", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "无法打开权限设置页", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }

        try {
            Uri fileUri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                fileUri = FileProvider.getUriForFile(
                        this,
                        getPackageName() + ".fileprovider",
                        file
                );
            } else {
                fileUri = Uri.fromFile(file);
            }

            Intent shareIntent = new Intent(Intent.ACTION_SEND);

            String mimeType = "*/*";
            String fileName = file.getName().toLowerCase();
            if (fileName.endsWith(".txt")) mimeType = "text/plain";
            else if (fileName.endsWith(".pdf")) mimeType = "application/pdf";
            else if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) mimeType = "image/jpeg";
            else if (fileName.endsWith(".png")) mimeType = "image/png";
            else if (fileName.endsWith(".zip")) mimeType = "application/zip";

            shareIntent.setType(mimeType);
            shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(Intent.createChooser(shareIntent, "分享文件"));
            } else {
                Toast.makeText(this, "未找到支持分享的应用", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "分享失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void confirmDelete(final File file, final Runnable after) {
        new AlertDialog.Builder(this)
            .setTitle("确认删除")
            .setMessage("确定要删除 " + file.getName() + " 吗？")
            .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    boolean ok = FileUtils.deleteRecursively(file);
                    File zip = new File(file.getAbsolutePath() + ".zip");
                    if (zip.exists()) zip.delete();
                    if (ok) {
                        Toast.makeText(MainActivity.this, "已删除", Toast.LENGTH_SHORT).show();
                        if (after != null) after.run();
                    } else {
                        Toast.makeText(MainActivity.this, "删除失败", Toast.LENGTH_SHORT).show();
                    }
                }
            })
            .setNegativeButton("取消", null)
            .show();
    }
}